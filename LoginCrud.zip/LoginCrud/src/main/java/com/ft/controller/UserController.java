/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ft.controller;

import com.ft.model.User;
import com.ft.service.LoginService;
import com.ft.service.UserService;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.portlet.ModelAndView;

/**
 *
 * @author Focus
 */
@Controller
public class UserController {
    @Autowired
    private UserService userService;
    
    @Autowired
    private LoginService loginService;
    
    @RequestMapping(value="/registration",method=RequestMethod.GET)
    public String getRegistrationPage(ModelMap map){
        User user =new User();
        map.addAttribute("user", user);
        return "/registration";
    }
    
    @RequestMapping(value="/registration",method=RequestMethod.POST)
    public String onClickRegistrationPage(@ModelAttribute("user") User user,HttpServletRequest req,ModelMap map) throws ServletRequestBindingException{
        
        int count1=this.userService.validateUser(user);
        if(count1==0){
            int count2=this.userService.registerUser(user);
        
            if(count2>0){
             return "/register_success";
            }
            else{
                map.addAttribute("msg"," Not Registerd Successfully");
                return "/home";
            }
        }
        else{
            map.addAttribute("msg"," User already Exist");
            return "/registration";
        }
    }
    
    @RequestMapping(value="/forgotpassword",method=RequestMethod.GET)
    public String getForgotPasswordPage(){
            return "/forgotpassword";
    }
    
    @RequestMapping(value="/forgotpassword",method=RequestMethod.POST)
    public String onSubmitForgotPasswordPage(HttpServletRequest req,ModelMap map) throws ServletRequestBindingException{
        String username=ServletRequestUtils.getStringParameter(req,"fusername");
        System.out.println(username);
        
        int count =this.loginService.validateUser(username);
        System.out.println(count);
        if(count>0){
            
            return "redirect:/enternewpassword.htm";
        }
        else{
            map.addAttribute("username", username);
            map.addAttribute("msg","User name doesn't exist");
            return "/forgotpassword";
        }
        
    }
    
    @RequestMapping(value="/enternewpassword",method=RequestMethod.GET)
    public String getEnterNewPasswordPage(){
        return "/enternewpassword";
    }
    
    @RequestMapping(value="/enternewpassword",method=RequestMethod.POST)
    public String onSubmitEnterNewPasswordPage(HttpServletRequest req,ModelMap map) throws ServletRequestBindingException{
        
        String newpassword=ServletRequestUtils.getStringParameter(req,"newuserpassword");
        String username=ServletRequestUtils.getStringParameter(req,"username");
        System.out.println("2");
        System.out.println(newpassword+"...."+username);
        //System.out.println(newpassword+"...."+username);
        int count=this.userService.insertNewPassword(username, newpassword);
        
        if(count>0){
            return "/passwordchanged";
        }
        else{
            map.addAttribute("msg","Error in Changing Password");
            return "/enternewpassword";
        }
    }
    
//    Method for Listing All Users
    @RequestMapping(value="/userList",method=RequestMethod.GET)
    public String getUserList(HttpServletRequest req,HttpServletResponse res,ModelMap map) throws Exception{
        List<User> userList=this.userService.getAllUserList();
        map.addAttribute("userList", userList);
       String msg= ServletRequestUtils.getStringParameter(req, "msg");
       map.addAttribute("msg", msg);
        return "/userList";         
    }
    
//  Method for Deleting the User form the User list
    @RequestMapping(value="/deleteuser")
    public String deleteUser(HttpServletRequest req,ModelMap map)throws Exception{
        int userId=ServletRequestUtils.getIntParameter(req,"userId");
        int count=this.userService.deleteUser(userId);
        if(count>0){
            map.addAttribute("msg", "User Deleted Successfully");
        }
        return  "redirect:/userList.htm";
    }
    
    @RequestMapping(value="/edituser",method=RequestMethod.GET)
    public String editUser(HttpServletRequest req,ModelMap map) throws ServletRequestBindingException{
        int userId=ServletRequestUtils.getIntParameter(req, "userId");
        User user=this.userService.getUserById(userId);
        map.addAttribute("user", user);
        return "/edituser";
    }
    
    @RequestMapping(value="/edituser",method=RequestMethod.POST)
    public String onClickEditUserPage(@ModelAttribute("user") User user,HttpServletRequest req,ModelMap map) throws ServletRequestBindingException{    
        
        System.out.println("user================= "+user);
        int result=this.userService.editUser(user);
        
        System.out.println("===============================count"+result);
        if(result>0){
            map.addAttribute("msg","User Information Update Successfully");
            return "redirect:/userList.htm";    
        }
        else{
            map.addAttribute("msg","User Information Not Update Successfully");
            return "redirect:/userList.htm";
        }
    }
}
