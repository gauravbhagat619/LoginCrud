/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ft.controller;

import com.ft.model.User;
import com.ft.service.LoginService;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author Focus
 */
@Controller
public class LoginController {
    @Autowired
    LoginService loginService;
    
    @RequestMapping(value="/home",method=RequestMethod.GET)
    public String getLoginPage(){
        return "/home";
    }
    
    @RequestMapping(value="/home",method=RequestMethod.POST)
    public String onSubmitLoginPage(HttpServletRequest req,ModelMap map) throws ServletRequestBindingException{
        String userid=null,password=null;
        boolean active=false;
        
        userid=ServletRequestUtils.getStringParameter(req, "uname");
        password=ServletRequestUtils.getStringParameter(req,"password");
        
         System.out.println("======================"+userid+"======="+password);
        try{
        User user=this.loginService.validateUser(userid, password);
        System.out.println("======================"+user);
        if(user==null){
            map.addAttribute("msg","UserName or Password is Incorrect"); 
            return "/home";
        }
        else{
            if(!user.isActive()){
                map.addAttribute("msg","User is Disabled");  
                return "/home";
            }
            else{
                 map.addAttribute("username",userid);
                return "/welcome";
            }  
        }
        }
        catch(Exception e){
            e.printStackTrace();
           
            map.addAttribute("msg","UserName or Password is Incorrect");
            return "/home";
        }
    }
}
