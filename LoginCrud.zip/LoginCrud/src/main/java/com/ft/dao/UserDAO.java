/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ft.dao;

import com.ft.model.User;
import java.util.List;

/**
 *
 * @author Focus
 */
public interface UserDAO {
    
   public int registerUser(User user);
    
    public int insertNewPassword(String username,String password);
    
    public int validateUser(User user);
    
    public List<User> getAllUserList();
    
    public int deleteUser(int userId);
    
    public User getUserById(int userId);
    
    public int editUser(User user);
}
