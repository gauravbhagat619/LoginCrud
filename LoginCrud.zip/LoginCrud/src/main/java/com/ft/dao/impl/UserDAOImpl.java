/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ft.dao.impl;

import com.ft.dao.UserDAO;
import static com.ft.dao.impl.LoginDAOImpl.FORGOT_QUERY;
import com.ft.mapper.UserRowMapper;
import com.ft.model.User;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Focus
 */
@Repository
public class UserDAOImpl implements UserDAO {

    public static final String REGISTER_USER = "INSERT INTO `user_login` VALUES(null,?,?,?)";

    public static final String INSERT_NEW_PASSWORD = "UPDATE `user_login` SET PASSWORD=? WHERE user_login.username=?;";
    public static final String VALIDATE_QUERY = "SELECT count(*) FROM `user_login` WHERE user_login.USERNAME=?";

    private JdbcTemplate jdbcTemplate;
    private DataSource dataSource;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public int registerUser(User user) {
        PasswordEncoder encoder = new Md5PasswordEncoder();
        String hashPass = encoder.encodePassword(user.getPassword(), null);
        int count = this.jdbcTemplate.update(REGISTER_USER, user.getUsername(), hashPass,user.isActive());
        return count;
    }

    @Override
    public int insertNewPassword(final String username, String password) {
        PasswordEncoder encoder = new Md5PasswordEncoder();
        final String hashPass = encoder.encodePassword(password, null);
        int count = this.jdbcTemplate.update(INSERT_NEW_PASSWORD, new PreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1, hashPass);
                ps.setString(2, username);
            }
        });
        System.out.println(count);
        return count;
    }

    @Override
    public int validateUser(User user) {
        String sql="SELECT count(*) FROM `user_login` WHERE user_login.USERNAME=?";
        int count = this.jdbcTemplate.queryForObject(sql, Integer.class, user.getUsername());
        return count;
    }

    @Override
    public List<User> getAllUserList() {
        String sql = "select * from user_login;";
        return this.jdbcTemplate.query(sql, new UserRowMapper());
    }

    @Override
    public int deleteUser(int userId) {
        String sql = "DELETE FROM user_login  WHERE USERID=?;";
        return this.jdbcTemplate.update(sql, userId);
    }

    @Override
    public User getUserById(int userId) {
        String sql = "select * from user_login where USERID=?";
        return this.jdbcTemplate.queryForObject(sql, new UserRowMapper(), userId);
    }

    @Override
    public int editUser(User user) {

        if (user.getPassword().isEmpty()) {
            String sql = "UPDATE user_login u SET u.`USERNAME`=?,u.`ACTIVE`=? WHERE u.`USERID`=?";
             Object params[] = {user.getUsername(), user.isActive(), user.getUserId()};
             return this.jdbcTemplate.update(sql, params);
        } 
        else {
            String sql = "UPDATE user_login u SET u.`USERNAME`=?,u.`PASSWORD`=?,u.`ACTIVE`=? WHERE u.`USERID`=?";
            PasswordEncoder encoder = new Md5PasswordEncoder();
            final String hashPass = encoder.encodePassword(user.getPassword(), null);
            Object params[] = {user.getUsername(), hashPass, user.isActive(), user.getUserId()};
            return this.jdbcTemplate.update(sql, params);
        }
       
        
    }

}
