/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ft.dao.impl;

import com.ft.dao.LoginDAO;
import com.ft.mapper.UserRowMapper;
import com.ft.model.User;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Focus
 */
@Repository
public class LoginDAOImpl implements LoginDAO{
    
    
    
    public static final String FORGOT_QUERY="SELECT COUNT(*) FROM `user_login` WHERE user_login.USERNAME=?";
    
    private JdbcTemplate jdbcTemplate;
    private DataSource dataSource;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplate= new JdbcTemplate( dataSource);
    }
    
    
    @Override
    public User validateUser(String username, String password) {
        String sql="SELECT * FROM `user_login` WHERE user_login.USERNAME=? AND user_login.PASSWORD=MD5(?)";
        User user =this.jdbcTemplate.queryForObject(sql,new UserRowMapper(),username,password);
        return  user;
    }
    
    @Override
    public int validateUser(String username) {
        int count=this.jdbcTemplate.queryForObject(FORGOT_QUERY,Integer.class,username);
        return count;
    }
    
}
