/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ft.service.impl;

import com.ft.dao.LoginDAO;
import com.ft.model.User;
import com.ft.service.LoginService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Focus
 */
@Service
public class LoginServiceImpl implements LoginService {
    
    @Autowired
    LoginDAO loginDAO;
    
    @Override
    public User validateUser(String username, String password) {
        return this.loginDAO.validateUser(username, password);       
     }

    @Override
    public int validateUser(String username) {
        return this.loginDAO.validateUser(username);
    }
    
}
