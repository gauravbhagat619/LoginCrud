/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ft.service.impl;

import com.ft.dao.UserDAO;
import com.ft.model.User;
import com.ft.service.UserService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Focus
 */
@Service
public class UserServiceImpl implements UserService{
    
    @Autowired
    private UserDAO userDAO;

    @Override
    public int registerUser(User user) {
        int count=this.userDAO.registerUser(user);
        return count;
       
    }

    @Override
    public int insertNewPassword(String username, String password) {
        int count=this.userDAO.insertNewPassword(username, password);
        return count;
    }

    @Override
    public List<User> getAllUserList() {
        return this.userDAO.getAllUserList();
    }

    @Override
    public int validateUser(User user) {
       return this.userDAO.validateUser(user);
    }

    @Override
    public int deleteUser(int userId) {
        return this.userDAO.deleteUser(userId);
    }

    @Override
     public int editUser(User user) {
        return this.userDAO.editUser(user);
    }

    @Override
    public User getUserById(int userId) {
        return this.userDAO.getUserById(userId);
    }
    
}
